// EventsPage.jsx
const EventsPage = () => {
  const theme = React.useContext(ThemeCtx);
  const [visible, setVisible] = React.useState({});
  const [search, setSearch] = React.useState('');

  React.useEffect(() => {
    window.scrollTo(0, 0);
    const els = document.querySelectorAll('[data-reveal]');
    const obs = new IntersectionObserver(entries => {
      entries.forEach(e => { if (e.isIntersecting) setVisible(v => ({ ...v, [e.target.dataset.reveal]: true })); });
    }, { threshold: 0.08 });
    els.forEach(el => obs.observe(el));
    return () => obs.disconnect();
  }, []);

  const rev = (key, delay = 0) => ({
    opacity: visible[key] ? 1 : 0,
    transform: visible[key] ? 'translateY(0)' : 'translateY(28px)',
    transition: `opacity 0.7s ${delay}s cubic-bezier(0.16,1,0.3,1), transform 0.7s ${delay}s cubic-bezier(0.16,1,0.3,1)`,
  });

  const events = [
    { id: 1, tag: 'Dogodki', date: '10. apr. 2026', title: 'Uvodni sestanek alpinistične šole', location: 'Klubi prostori, Tačen', time: '18:00', desc: 'Spoznajte inštruktorje, program in sotekmovalce. Obvezna prisotnost za vse prijavljene.', color: '#E8501A' },
    { id: 2, tag: 'Tura', date: '18. apr. 2026', title: 'Spomladanska tura na Storžič', location: 'Storžič, Kamniške Alpe', time: '07:00', desc: 'Skupinska dnevna tura. Primerno za vse ravni. Obvezna prijava.', color: '#3a7bd5' },
    { id: 3, tag: 'Predavanje', date: '25. apr. 2026', title: 'Varnost v visokogorju', location: 'Online / Zoom', time: '19:00', desc: 'Predavanje izkušenega alpinista o tehnikah varovanja in reševanja v gorah.', color: '#2ec4b6' },
    { id: 4, tag: 'Dogodki', date: '3. maj 2026', title: 'Plezalni dan na Bohinjski skali', location: 'Bohinj', time: '09:00', desc: 'Skupni plezalni dan za člane. Prinesite lastno opremo ali si izposodite od kluba.', color: '#E8501A' },
    { id: 5, tag: 'Tura', date: '17. maj 2026', title: 'Vikend odprava — Julijske Alpe', location: 'Triglav NP', time: '06:00', desc: 'Dvodnevna tura po Julijskih Alpah. Prenočevanje v planinskem domu.', color: '#3a7bd5' },
  ];

  const filtered = events.filter(e =>
    e.title.toLowerCase().includes(search.toLowerCase()) ||
    e.location.toLowerCase().includes(search.toLowerCase())
  );
  const featuredEvent = filtered[0];
  const otherEvents = filtered.slice(1);

  return (
    <div style={{ background: theme.bg, minHeight: '100vh', color: theme.text, transition: 'background 0.4s, color 0.4s' }}>
      {/* Hero */}
      <div style={{ position: 'relative', height: '55vh', overflow: 'hidden', display: 'flex', alignItems: 'flex-end' }}>
        <div style={{ position: 'absolute', inset: 0, backgroundImage: "url('https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=1600&q=80')", backgroundSize: 'cover', backgroundPosition: 'center 50%' }} />
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to bottom, rgba(0,0,0,0.1) 0%, rgba(10,10,10,0.97) 100%)' }} />
        <div style={{ position: 'relative', zIndex: 1, padding: '0 72px 64px', maxWidth: '1100px' }}>
          <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '12px', letterSpacing: '0.3em', textTransform: 'uppercase', color: '#E8501A', marginBottom: '16px', opacity: 0, animation: 'fadeUp 0.8s 0.3s forwards' }}>Koledar</div>
          <h1 style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 800, fontSize: 'clamp(56px,8vw,96px)', lineHeight: 0.95, margin: '0 0 16px', color: '#fff', opacity: 0, animation: 'fadeUp 0.8s 0.5s forwards' }}>
            Dogodki &amp;<br /><span style={{ color: '#E8501A' }}>Prireditve</span>
          </h1>
          <p style={{ fontFamily: "'Inter', sans-serif", fontWeight: 300, fontSize: '17px', color: 'rgba(255,255,255,0.55)', opacity: 0, animation: 'fadeUp 0.8s 0.7s forwards' }}>Vse kar se dogaja v klubu — ture, predavanja, srečanja in več.</p>
        </div>
      </div>

      {/* Stats */}
      <div style={{ background: theme.statBg, borderTop: `1px solid ${theme.border}`, borderBottom: `1px solid ${theme.border}`, transition: 'background 0.4s' }}>
        <div style={{ maxWidth: '1100px', margin: '0 auto', display: 'grid', gridTemplateColumns: 'repeat(3,1fr)' }}>
          {[{ val: filtered.length, label: 'Dogodki' }, { val: 2, label: 'Ta mesec' }, { val: 2, label: 'Organizatorji' }].map((s, i) => (
            <div key={i} style={{ padding: '32px 24px', textAlign: 'center', borderRight: i < 2 ? `1px solid ${theme.border}` : 'none' }}>
              <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 800, fontSize: '44px', color: '#E8501A', lineHeight: 1 }}>{s.val}</div>
              <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '11px', letterSpacing: '0.2em', textTransform: 'uppercase', color: theme.textLow, marginTop: '6px' }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '64px 72px 96px' }}>
        {/* Search */}
        <div data-reveal="search" style={{ ...rev('search'), marginBottom: '48px' }}>
          <div style={{ position: 'relative', maxWidth: '360px' }}>
            <svg style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', opacity: 0.35 }} width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={theme.text} strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Išči dogodke..."
              style={{ width: '100%', boxSizing: 'border-box', background: theme.inputBg, border: `1px solid ${theme.border}`, borderRadius: '6px', padding: '11px 14px 11px 40px', color: theme.text, fontFamily: "'Inter', sans-serif", fontSize: '14px', outline: 'none', transition: 'border-color 0.2s, background 0.4s' }}
              onFocus={e => e.target.style.borderColor='rgba(232,80,26,0.5)'}
              onBlur={e => e.target.style.borderColor=theme.border} />
          </div>
        </div>

        {/* Featured */}
        {featuredEvent && (
          <div data-reveal="featured-event" style={{ ...rev('featured-event'), marginBottom: '48px' }}>
            <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '11px', letterSpacing: '0.25em', textTransform: 'uppercase', color: theme.textFaint, marginBottom: '16px' }}>— Naslednji dogodek</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', background: theme.bgCard, border: `1px solid ${theme.border}`, borderRadius: '10px', overflow: 'hidden', transition: 'border-color 0.3s, background 0.4s' }}
              onMouseEnter={e => e.currentTarget.style.borderColor='rgba(232,80,26,0.4)'}
              onMouseLeave={e => e.currentTarget.style.borderColor=theme.border}>
              <div style={{ padding: '48px' }}>
                <div style={{ display: 'flex', gap: '12px', alignItems: 'center', marginBottom: '24px' }}>
                  <span style={{ background: featuredEvent.color, color: '#fff', fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: '11px', letterSpacing: '0.1em', textTransform: 'uppercase', padding: '4px 10px', borderRadius: '3px' }}>{featuredEvent.tag}</span>
                  <span style={{ color: theme.textLow, fontFamily: "'Inter', sans-serif", fontSize: '13px' }}>{featuredEvent.date}</span>
                </div>
                <h2 style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 800, fontSize: '38px', lineHeight: 1.05, margin: '0 0 16px', color: theme.text }}>{featuredEvent.title}</h2>
                <p style={{ fontFamily: "'Inter', sans-serif", fontSize: '15px', lineHeight: 1.7, color: theme.textMid, margin: '0 0 28px' }}>{featuredEvent.desc}</p>
                <div style={{ display: 'flex', gap: '24px' }}>
                  <span style={{ fontFamily: "'Inter', sans-serif", fontSize: '13px', color: theme.textLow }}>🕐 {featuredEvent.time}</span>
                  <span style={{ fontFamily: "'Inter', sans-serif", fontSize: '13px', color: theme.textLow }}>📍 {featuredEvent.location}</span>
                </div>
              </div>
              <div style={{ backgroundImage: "url('https://images.unsplash.com/photo-1551632811-561732d1e306?w=800&q=80')", backgroundSize: 'cover', backgroundPosition: 'center', minHeight: '300px', position: 'relative' }}>
                <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to right, rgba(20,20,20,0.4), transparent)' }} />
              </div>
            </div>
          </div>
        )}

        {/* List */}
        <div data-reveal="events-header" style={{ ...rev('events-header'), marginBottom: '24px' }}>
          <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '11px', letterSpacing: '0.25em', textTransform: 'uppercase', color: theme.textFaint }}>— Vsi dogodki</div>
        </div>
        <div data-reveal="events-list" style={{ ...rev('events-list'), display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {otherEvents.map((ev, i) => (
            <div key={ev.id} style={{ background: theme.bgCard, border: `1px solid ${theme.border}`, borderRadius: '8px', padding: '28px 32px', display: 'grid', gridTemplateColumns: '80px 1fr auto', gap: '24px', alignItems: 'center', cursor: 'pointer', transition: 'border-color 0.3s, transform 0.2s, background 0.4s' }}
            onMouseEnter={e => { e.currentTarget.style.borderColor='rgba(232,80,26,0.35)'; e.currentTarget.style.transform='translateX(6px)'; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor=theme.border; e.currentTarget.style.transform='translateX(0)'; }}>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 800, fontSize: '32px', color: ev.color, lineHeight: 1 }}>{String(i + 2).padStart(2, '0')}</div>
                <div style={{ fontFamily: "'Inter', sans-serif", fontSize: '11px', color: theme.textLow, marginTop: '2px' }}>{ev.date.split('. ').slice(0,2).join('. ')}</div>
              </div>
              <div>
                <div style={{ display: 'flex', gap: '10px', alignItems: 'center', marginBottom: '6px' }}>
                  <span style={{ background: ev.color + '22', color: ev.color, fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: '11px', letterSpacing: '0.08em', textTransform: 'uppercase', padding: '3px 8px', borderRadius: '3px' }}>{ev.tag}</span>
                </div>
                <h3 style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: '22px', margin: '0 0 6px', color: theme.text }}>{ev.title}</h3>
                <div style={{ display: 'flex', gap: '16px' }}>
                  <span style={{ fontFamily: "'Inter', sans-serif", fontSize: '13px', color: theme.textLow }}>🕐 {ev.time}</span>
                  <span style={{ fontFamily: "'Inter', sans-serif", fontSize: '13px', color: theme.textLow }}>📍 {ev.location}</span>
                </div>
              </div>
              <span style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: '13px', letterSpacing: '0.08em', color: '#E8501A', textTransform: 'uppercase', whiteSpace: 'nowrap' }}>Preberi →</span>
            </div>
          ))}
        </div>
      </div>
      <style>{`@keyframes fadeUp { from { opacity:0; transform:translateY(28px); } to { opacity:1; transform:translateY(0); } }`}</style>
    </div>
  );
};
Object.assign(window, { EventsPage });
