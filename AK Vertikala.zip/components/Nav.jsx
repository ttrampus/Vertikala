// Nav.jsx — Top navigation bar
const Nav = ({ currentPage, setPage, theme, darkMode, onToggleDark }) => {
  const [scrolled, setScrolled] = React.useState(false);
  const [menuOpen, setMenuOpen] = React.useState(false);
  const t = theme || { bg: '#0a0a0a', text: '#fff', navBg: 'rgba(10,10,10,0.92)', border: 'rgba(255,255,255,0.06)', textLow: 'rgba(255,255,255,0.7)', isDark: true };

  React.useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const links = [
    { id: 'home', label: 'Domov' },
    { id: 'about', label: 'O nas' },
    { id: 'events', label: 'Dogodki' },
    { id: 'school', label: 'Šola' },
    { id: 'contact', label: 'Kontakt' },
  ];

  const navStyle = {
    position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100,
    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
    padding: '0 48px',
    height: scrolled ? '64px' : '80px',
    background: scrolled ? t.navBg : 'transparent',
    backdropFilter: scrolled ? 'blur(16px)' : 'none',
    borderBottom: scrolled ? `1px solid ${t.border}` : 'none',
    transition: 'all 0.4s cubic-bezier(0.16,1,0.3,1)',
  };

  const textColor = (active) => {
    if (active) return '#E8501A';
    // on hero (not scrolled + dark page) always white; otherwise follow theme
    if (!scrolled) return '#fff';
    return t.isDark ? 'rgba(255,255,255,0.7)' : 'rgba(0,0,0,0.6)';
  };

  const hoverColor = () => (!scrolled || t.isDark) ? '#fff' : '#111';

  return (
    <nav style={navStyle}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer' }} onClick={() => { setPage('home'); setMenuOpen(false); }}>
        <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
          <polygon points="16,4 30,28 2,28" fill="none" stroke="#E8501A" strokeWidth="2.5" strokeLinejoin="round"/>
          <polygon points="16,11 23,28 9,28" fill="#E8501A" opacity="0.5"/>
        </svg>
        <span style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: '20px', letterSpacing: '0.04em', color: scrolled ? t.text : '#fff' }}>
          AK <span style={{ color: '#E8501A' }}>VERTIKALA</span>
        </span>
      </div>

      {/* Desktop links */}
      <div style={{ display: 'flex', gap: '36px', alignItems: 'center' }} className="nav-desktop">
        {links.map(l => (
          <button key={l.id} onClick={() => setPage(l.id)} style={{
            background: 'none', border: 'none', cursor: 'pointer',
            fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 600,
            fontSize: '14px', letterSpacing: '0.12em', textTransform: 'uppercase',
            color: textColor(currentPage === l.id),
            transition: 'color 0.2s',
            padding: '4px 0',
            borderBottom: currentPage === l.id ? '2px solid #E8501A' : '2px solid transparent',
          }}
          onMouseEnter={e => { if (currentPage !== l.id) e.target.style.color = hoverColor(); }}
          onMouseLeave={e => { if (currentPage !== l.id) e.target.style.color = textColor(false); }}
          >{l.label}</button>
        ))}

        {/* Dark / light mode toggle */}
        <button onClick={onToggleDark} title={darkMode ? 'Preklopi na svetli način' : 'Preklopi na temni način'} style={{
          background: 'none', border: 'none', cursor: 'pointer', padding: '6px',
          borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: scrolled ? t.text : '#fff',
          transition: 'color 0.2s, background 0.2s',
          opacity: 0.8,
        }}
        onMouseEnter={e => { e.currentTarget.style.opacity = '1'; e.currentTarget.style.background = 'rgba(128,128,128,0.15)'; }}
        onMouseLeave={e => { e.currentTarget.style.opacity = '0.8'; e.currentTarget.style.background = 'none'; }}
        >
          {darkMode ? (
            /* Sun icon — click to go light */
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="5"/>
              <line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/>
              <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>
              <line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/>
              <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>
            </svg>
          ) : (
            /* Moon icon — click to go dark */
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
            </svg>
          )}
        </button>

        <button onClick={() => setPage('login')} style={{
          background: '#E8501A', border: 'none', cursor: 'pointer',
          fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700,
          fontSize: '13px', letterSpacing: '0.12em', textTransform: 'uppercase',
          color: '#fff', padding: '9px 20px', borderRadius: '4px',
          transition: 'background 0.2s, transform 0.2s',
        }}
        onMouseEnter={e => { e.target.style.background = '#c73d10'; e.target.style.transform = 'translateY(-1px)'; }}
        onMouseLeave={e => { e.target.style.background = '#E8501A'; e.target.style.transform = 'translateY(0)'; }}
        >Prijava</button>
      </div>

      {/* Mobile hamburger */}
      <button onClick={() => setMenuOpen(!menuOpen)} className="nav-hamburger" style={{
        display: 'none', background: 'none', border: 'none', cursor: 'pointer',
        flexDirection: 'column', gap: '5px', padding: '4px',
      }}>
        {[0,1,2].map(i => (
          <span key={i} style={{
            display: 'block', width: '24px', height: '2px',
            background: scrolled ? t.text : '#fff', borderRadius: '2px',
            transition: 'all 0.3s',
            transform: menuOpen ? (i===0 ? 'rotate(45deg) translate(5px,5px)' : i===2 ? 'rotate(-45deg) translate(5px,-5px)' : 'scaleX(0)') : 'none',
          }}/>
        ))}
      </button>

      {/* Mobile menu */}
      {menuOpen && (
        <div style={{
          position: 'absolute', top: '100%', left: 0, right: 0,
          background: t.isDark ? 'rgba(10,10,10,0.97)' : 'rgba(245,244,240,0.97)',
          backdropFilter: 'blur(16px)',
          padding: '24px 48px 32px', display: 'flex', flexDirection: 'column', gap: '20px',
          borderBottom: `1px solid ${t.border}`,
        }}>
          {links.map(l => (
            <button key={l.id} onClick={() => { setPage(l.id); setMenuOpen(false); }} style={{
              background: 'none', border: 'none', cursor: 'pointer', textAlign: 'left',
              fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 600,
              fontSize: '18px', letterSpacing: '0.1em', textTransform: 'uppercase',
              color: currentPage === l.id ? '#E8501A' : t.text,
            }}>{l.label}</button>
          ))}
        </div>
      )}
    </nav>
  );
};

Object.assign(window, { Nav });
