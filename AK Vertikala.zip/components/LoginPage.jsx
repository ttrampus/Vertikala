// LoginPage.jsx
const LoginPage = ({ setPage }) => {
  const theme = React.useContext(ThemeCtx);
  const [tab, setTab] = React.useState('signin');
  const [form, setForm] = React.useState({ email: '', password: '', name: '', confirm: '' });
  const [showPass, setShowPass] = React.useState(false);
  const [loading, setLoading] = React.useState(false);

  React.useEffect(() => { window.scrollTo(0, 0); }, []);

  const inputStyle = {
    width: '100%', boxSizing: 'border-box',
    background: theme.inputBg, border: `1px solid ${theme.border}`,
    borderRadius: '6px', padding: '13px 16px',
    color: theme.text, fontFamily: "'Inter', sans-serif", fontSize: '14px',
    outline: 'none', transition: 'border-color 0.2s, background 0.4s',
  };

  const labelStyle = {
    fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 600,
    fontSize: '11px', letterSpacing: '0.15em', textTransform: 'uppercase',
    color: theme.textLow, display: 'block', marginBottom: '8px',
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => { setLoading(false); setPage('home'); }, 1200);
  };

  return (
    <div style={{
      background: theme.bg, minHeight: '100vh', color: theme.text,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: '100px 24px 60px', position: 'relative', overflow: 'hidden',
      transition: 'background 0.4s, color 0.4s',
    }}>
      {/* Background glow */}
      <div style={{ position: 'absolute', top: '-200px', left: '50%', transform: 'translateX(-50%)', width: '600px', height: '600px', background: 'radial-gradient(circle, rgba(232,80,26,0.06) 0%, transparent 70%)', borderRadius: '50%', pointerEvents: 'none' }} />

      <div style={{ width: '100%', maxWidth: '440px', position: 'relative', zIndex: 1 }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: '40px' }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '12px', cursor: 'pointer' }} onClick={() => setPage('home')}>
            <div style={{ width: '48px', height: '48px', background: 'rgba(232,80,26,0.15)', border: '2px solid rgba(232,80,26,0.4)', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <svg width="26" height="26" viewBox="0 0 32 32" fill="none">
                <polygon points="16,4 30,28 2,28" fill="none" stroke="#E8501A" strokeWidth="2.5" strokeLinejoin="round"/>
                <polygon points="16,11 23,28 9,28" fill="#E8501A" opacity="0.5"/>
              </svg>
            </div>
            <div style={{ textAlign: 'left' }}>
              <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 800, fontSize: '18px', lineHeight: 1, letterSpacing: '0.04em', color: theme.text }}>
                AK <span style={{ color: '#E8501A' }}>VERTIKALA</span>
              </div>
              <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '11px', letterSpacing: '0.15em', textTransform: 'uppercase', color: theme.textLow, marginTop: '2px' }}>Alpinistični klub</div>
            </div>
          </div>
        </div>

        {/* Card */}
        <div style={{ background: theme.bgCard, border: `1px solid ${theme.border}`, borderRadius: '16px', padding: '40px', boxShadow: theme.isDark ? '0 40px 80px rgba(0,0,0,0.4)' : '0 20px 60px rgba(0,0,0,0.1)', transition: 'background 0.4s, border-color 0.4s' }}>
          {/* Google */}
          <button style={{ width: '100%', background: theme.bgAlt, border: `1px solid ${theme.border}`, borderRadius: '8px', padding: '13px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px', cursor: 'pointer', marginBottom: '24px', transition: 'border-color 0.2s, background 0.4s' }}
          onMouseEnter={e => { e.currentTarget.style.borderColor=theme.borderMid; }}
          onMouseLeave={e => { e.currentTarget.style.borderColor=theme.border; }}>
            <svg width="18" height="18" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
            <span style={{ fontFamily: "'Inter', sans-serif", fontSize: '14px', color: theme.textMid, fontWeight: 500 }}>Nadaljuj z Googlom</span>
          </button>

          {/* Divider */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '24px' }}>
            <div style={{ flex: 1, height: '1px', background: theme.border }} />
            <span style={{ fontFamily: "'Inter', sans-serif", fontSize: '12px', color: theme.textFaint }}>ali</span>
            <div style={{ flex: 1, height: '1px', background: theme.border }} />
          </div>

          {/* Tabs */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', background: theme.bgAlt, borderRadius: '8px', padding: '4px', marginBottom: '28px', transition: 'background 0.4s' }}>
            {[['signin', 'Prijava'], ['register', 'Registracija']].map(([id, label]) => (
              <button key={id} onClick={() => setTab(id)} style={{ background: tab === id ? '#E8501A' : 'transparent', border: 'none', borderRadius: '6px', padding: '10px', fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: '14px', letterSpacing: '0.06em', textTransform: 'uppercase', color: tab === id ? '#fff' : theme.textLow, cursor: 'pointer', transition: 'all 0.2s' }}>{label}</button>
            ))}
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '18px' }}>
            {tab === 'register' && (
              <div>
                <label style={labelStyle}>Ime in priimek</label>
                <input required value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Vaše ime" style={inputStyle}
                  onFocus={e => e.target.style.borderColor='rgba(232,80,26,0.5)'} onBlur={e => e.target.style.borderColor=theme.border} />
              </div>
            )}
            <div>
              <label style={labelStyle}>E-pošta</label>
              <input required type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} placeholder="vasa@email.com" style={inputStyle}
                onFocus={e => e.target.style.borderColor='rgba(232,80,26,0.5)'} onBlur={e => e.target.style.borderColor=theme.border} />
            </div>
            <div>
              <label style={labelStyle}>Geslo</label>
              <div style={{ position: 'relative' }}>
                <input required type={showPass ? 'text' : 'password'} value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} placeholder="••••••••" style={{ ...inputStyle, paddingRight: '48px' }}
                  onFocus={e => e.target.style.borderColor='rgba(232,80,26,0.5)'} onBlur={e => e.target.style.borderColor=theme.border} />
                <button type="button" onClick={() => setShowPass(s => !s)} style={{ position: 'absolute', right: '14px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', padding: 0, color: theme.textLow }}>
                  {showPass
                    ? <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
                    : <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                  }
                </button>
              </div>
            </div>
            {tab === 'register' && (
              <div>
                <label style={labelStyle}>Potrdi geslo</label>
                <input required type="password" value={form.confirm} onChange={e => setForm(f => ({ ...f, confirm: e.target.value }))} placeholder="••••••••" style={inputStyle}
                  onFocus={e => e.target.style.borderColor='rgba(232,80,26,0.5)'} onBlur={e => e.target.style.borderColor=theme.border} />
              </div>
            )}
            {tab === 'signin' && (
              <div style={{ textAlign: 'right', marginTop: '-8px' }}>
                <button type="button" style={{ background: 'none', border: 'none', cursor: 'pointer', fontFamily: "'Inter', sans-serif", fontSize: '13px', color: '#E8501A', padding: 0 }}>Pozabljeno geslo?</button>
              </div>
            )}
            <button type="submit" disabled={loading} style={{ background: loading ? '#7a2c0d' : '#E8501A', color: '#fff', border: 'none', cursor: 'pointer', fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: '15px', letterSpacing: '0.1em', textTransform: 'uppercase', padding: '15px', borderRadius: '8px', marginTop: '4px', transition: 'all 0.2s', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}
            onMouseEnter={e => { if (!loading) e.currentTarget.style.background='#c73d10'; }}
            onMouseLeave={e => { if (!loading) e.currentTarget.style.background='#E8501A'; }}>
              {loading ? (<><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" style={{ animation: 'spin 0.8s linear infinite' }}><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>Prijavljam...</>) : (tab === 'signin' ? 'Prijava →' : 'Ustvari račun →')}
            </button>
          </form>
        </div>

        <div style={{ textAlign: 'center', marginTop: '24px' }}>
          <button onClick={() => setPage('home')} style={{ background: 'none', border: 'none', cursor: 'pointer', fontFamily: "'Inter', sans-serif", fontSize: '13px', color: theme.textFaint, transition: 'color 0.2s' }}
          onMouseEnter={e => e.target.style.color=theme.textMid}
          onMouseLeave={e => e.target.style.color=theme.textFaint}>← Nazaj na domačo stran</button>
        </div>
      </div>
      <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
    </div>
  );
};
Object.assign(window, { LoginPage });
